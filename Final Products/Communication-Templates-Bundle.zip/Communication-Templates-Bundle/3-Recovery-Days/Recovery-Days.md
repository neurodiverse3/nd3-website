# Recovery days

*You're in it right now and need to go quiet or hand something off.*

## 17. I'm having a bad day, going offline

*Use when: you need to disappear for a bit and want people to know not to worry.*

**Warm / Message**

> I'm having a rough one and I'm going to go offline for a bit to look after myself. I'm safe, just depleted. I'll resurface when I can. No need to worry about me. x
>

**Warm / Email**

Subject: **Going quiet for a bit**

Hi [name], I wanted to let you know rather than just vanish: I'm having a hard day and I'm going to step back and go quiet for a while to recover. I'm okay. This is me taking care of myself, not a crisis. I'll be back in touch when I've got something in the tank again. [you]

**Neutral / Message**

> Having a bad day, going offline for a bit to recover. I'm safe, just depleted. Back when I can.
>

**Neutral / Email**

Subject: **Offline for a bit**

Hi [name], I'm having a hard day and going quiet to recover. Nothing to worry about. I'll be back in touch when I can. [you]

**Brief / Message**

> Bad day, going offline to recover. I'm safe. Back when I can x
>

**Brief / Email**

Subject: **Going quiet**

Hi [name], rough day, going offline to recover. I'm okay. Back soon. [you]

--

## 18. Telling a partner or housemate you need space

*Use when: you live with someone and need them to give you room without taking it personally.*

**Warm / Message**

> I'm running on empty and I need some quiet space this evening. It's honestly not about you at all. If I'm in my own world for a bit, that's why. I love you and I'll be better for the reset. x
>

**Warm / Email**

Subject: **Needing some quiet**

Hi [name], I just wanted to say where my head's at so you're not left guessing: I'm completely depleted and I need some low-demand, quiet space for a while. It is genuinely nothing you've done. If I go a bit inward, please don't read anything into it. I just need to recharge, and I'll be much more myself afterwards. [you]

**Neutral / Message**

> I'm running on empty and need some quiet space tonight. Not about you. I just need to recharge.
>

**Neutral / Email**

Subject: **Need some space tonight**

Hi [name], I'm depleted and need some quiet, low-demand space this evening. It's not about you. I just need to recover. [you]

**Brief / Message**

> Running on empty, need some quiet space tonight. Not about you x
>

**Brief / Email**

Subject: **Need quiet tonight**

Hi [name], depleted, need quiet space tonight. Not about you. [you]

--

## 19. Letting work know you're low capacity

*Use when: you're not off sick, but you can't operate at full tilt and want to set expectations.*

**Warm / Message**

> Morning [name], I'm at work but running low today, so I'm going to keep to essentials and may be slower than usual. I'll flag anything urgent. Just wanted to be upfront rather than quietly struggle. x
>

**Warm / Email**

Subject: **Working at reduced capacity today**

Hi [name], I wanted to give you a heads-up: I'm in and working, but I'm at reduced capacity today, so I'm going to focus on the essentials and may be a little slower to respond. Nothing's wrong that time won't fix. I'd just rather be transparent than push through and let quality slip. I'll flag anything time-sensitive proactively. Thanks for understanding. [you]

**Neutral / Message**

> I'm working but at reduced capacity today, keeping to essentials and may be slower. Will flag anything urgent.
>

**Neutral / Email**

Subject: **Reduced capacity today**

Hi [name], flagging that I'm working at reduced capacity today. I'll prioritise essentials and may be slower than usual. I'll raise anything urgent. Thanks. [you]

**Brief / Message**

> Working but low capacity today, essentials only, may be slow. Will flag anything urgent.
>

**Brief / Email**

Subject: **Low capacity today**

Hi [name], at reduced capacity today, essentials only, may be slower. Thanks. [you]

--

## 20. Asking someone to handle a task for you

*Use when: you can't manage something today and need to hand it off.*

**Warm / Message**

> Could I lean on you for [task] today? I'm running on empty and I can't get to it properly. I'll happily return the favour, just can't do it justice right now. Thank you. x
>

**Warm / Email**

Subject: **Could you cover [task]?**

Hi [name], I don't ask lightly, but would you be able to take [task] off my plate today? I'm depleted and I can't give it the attention it needs without it costing me dearly. I'm very happy to return the favour, and I'll make sure you've got whatever you need to pick it up. Thank you so much. [you]

**Neutral / Message**

> Could you cover [task] today? I'm running low and can't get to it properly. Happy to return the favour.
>

**Neutral / Email**

Subject: **Cover [task] today?**

Hi [name], would you be able to take on [task] today? I'm low on capacity and can't do it justice. I'll send over anything you need. Thanks. [you]

**Brief / Message**

> Could you cover [task] today? Running on empty. I'll return the favour x
>

**Brief / Email**

Subject: **Cover [task]?**

Hi [name], can you take [task] today? I'm depleted. I'll send what you need. Thanks. [you]

--

## 21. I'm okay, just depleted (don't worry)

*Use when: someone's checking in and you want to reassure without performing fine-ness.*

**Warm / Message**

> Thank you for checking in. It means a lot. I'm okay, honestly, just very depleted and running quiet. Nothing's wrong that rest won't fix. I'll be back to myself soon. x
>

**Warm / Email**

Subject: **Thanks for checking in**

Hi [name], thank you for reaching out. It genuinely means a lot to be thought of. I want to reassure you: I'm okay. I'm just depleted and keeping things quiet while I recharge. There's nothing to fix and nothing you need to do. I'll be more myself before long. [you]

**Neutral / Message**

> Thanks for checking in. I'm okay, just depleted and running quiet. Nothing rest won't fix.
>

**Neutral / Email**

Subject: **I'm okay, thanks**

Hi [name], thanks for checking in. I'm fine, just low on energy and keeping quiet while I recover. Nothing to worry about. [you]

**Brief / Message**

> Thanks for checking in. I'm okay, just depleted. Nothing to worry about x
>

**Brief / Email**

Subject: **I'm okay**

Hi [name], thanks for checking in, I'm fine, just depleted. No worries. [you]

--

## 22. Pushing a social plan to a better day

*Use when: you don't want to cancel outright, just move it to when you'll actually enjoy it.*

**Warm / Message**

> I still really want to see you, but I'm running low and I'd be poor company today. Could we shift to [day] when I can actually be present and enjoy it? I'd much rather do that than show up empty. x
>

**Warm / Email**

Subject: **Let's move our plan to a better day**

Hi [name], I'm not cancelling on you. I genuinely want to see you. But I'm depleted right now and I'd rather not turn up as a shell of myself. Could we move it to [day], when I'll actually have the energy to be present and enjoy your company? You deserve more than the leftovers of my day. [you]

**Neutral / Message**

> I still want to see you, but I'm low today and wouldn't be good company. Could we move it to [day]?
>

**Neutral / Email**

Subject: **Moving our plan to [day]?**

Hi [name], I'd like to keep our plan but move it. I'm depleted today and wouldn't be present. Could we do [day] instead? [you]

**Brief / Message**

> Still want to see you, but I'm low today. Can we move to [day]? x
>

**Brief / Email**

Subject: **Move to [day]?**

Hi [name], want to see you but I'm depleted today, can we move to [day]? [you]

--

## 23. Letting a friend know you've gone quiet (it's not them)

*Use when: you've been absent and want to reassure a friend before they assume the worst.*

**Warm / Message**

> I know I've gone quiet and I didn't want you to think it's about you. It really isn't. I've been low on capacity and keeping my world small. I think about you and I'll be back properly soon. x
>

**Warm / Email**

Subject: **Not ignoring you, promise**

Hi [name], I've noticed I've been quiet lately and I didn't want you reading anything into it. It's honestly not about you at all. I've been running low and have had to shrink my world down to cope. You matter to me, and I'll be back in proper contact as soon as I've got more to give. Thank you for being patient with me. [you]

**Neutral / Message**

> I know I've gone quiet. It's not about you. I've been low on capacity. I'll be back properly soon.
>

**Neutral / Email**

Subject: **Sorry I've been quiet**

Hi [name], I've been quiet lately and wanted to say it's not about you. I've been low on energy and keeping things small. I'll be back in touch properly soon. [you]

**Brief / Message**

> I know I've gone quiet. It's not you, just low capacity. Back soon x
>

**Brief / Email**

Subject: **Sorry I've been quiet**

Hi [name], been quiet lately, not about you, just low capacity. Back soon. [you]

--

## 24. Re-emerging after a recovery day

*Use when: you're coming back into contact and want to do it lightly, without a big apology spiral.*

**Warm / Message**

> Back on the surface. Thank you for giving me the space. No need to catch me up on everything at once; I'll get there. Just glad to be reachable again. x
>

**Warm / Email**

Subject: **Resurfacing**

Hi [name], I'm back and feeling more like myself after some quiet time. Thank you for being patient while I went under for a bit. There's no need to flood me to catch up; I'll work through things at a steady pace. Good to be back in touch. [you]

**Neutral / Message**

> Back now. Thanks for the space. No rush to catch me up on everything; I'll get there.
>

**Neutral / Email**

Subject: **Back in touch**

Hi [name], I'm back after some quiet time. Thanks for your patience. I'll catch up at a steady pace. Good to be reachable again. [you]

**Brief / Message**

> Back now. Thanks for the space. I'll catch up slowly x
>

**Brief / Email**

Subject: **Back**

Hi [name], back after some quiet time, thanks for the patience. [you]