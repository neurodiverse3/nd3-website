## 📄 README: How to customise without losing the tone

*This is the README file for the ZIP. Keep it short; it's there to reassure, not to lecture.*

### What's in this bundle

- **24 templates** across three folders: *Cancellations*, *Boundaries*, *Recovery days*.
- Each template comes in **three tones** (warm, neutral, brief) and **two formats** (short message and longer email).
- Every template is supplied as plain `.txt`, `.md` and `.docx` so it works in any app: email, Slack, WhatsApp, Messages, paper, anywhere with text.
- A **decision card** to help you pick when you're too depleted to choose.

### How to use them

1. Open the folder that matches your situation (use the decision card if unsure).
2. Pick the tone that fits the relationship: warm for people you're close to, neutral for most situations, brief for when you've got nothing spare.
3. Copy the message or email version.
4. Swap anything in [square brackets] for the real detail.
5. Send. You're done.

### Customising without breaking the voice

- **Keep it shorter, not longer.** If you're unsure, cut a sentence rather than adding one. These work because they don't over-explain.
- **You don't owe a reason.** Several templates deliberately leave the "why" out. Resist the urge to justify yourself; "I can't today" is a complete sentence.
- **Swap the warmth markers to taste.** The "x" sign-offs and "thank you"s are optional. Strip them for a colder relationship; keep them for a close one.
- **Match the tone to the person, not your guilt.** Pick brief because you're low, not because you think you're a burden. You're not.
- **Don't apologise twice.** One "sorry" is plenty. More than that and you start handing the other person your discomfort to manage.

### A note

These are tools, not scripts you're obliged to follow word-for-word. If a line doesn't sound like you, change it. The goal is to get the message *sent* on a day when finding the words yourself would cost too much.

*Refundable for 14 days, no questions.*