## 🪪 Decision card: "Which template do I need?"

*For when you're too depleted to choose. Start at the top and stop at the first yes.*

- **Are you pulling out of something you'd already agreed to?** → *Cancellations*
- **Are you protecting your time, energy, or space going forward?** → *Boundaries*
- **Are you in it right now and need to go quiet / hand something off?** → *Recovery days*

*Still stuck? Default to a brief tone. Short and honest beats perfect and unsent.*